APA SAJA YANG BARU DARI THEMES LABS V.0.4 BETA
 + Memperbaiki KEsalahan Tata Letak Pada V.0.3
 + Button Widget Versi Mobile Telah Diperbaiki 
 + Penambahan Preloader 

PERHATIAN / MOHON DIBACA

Sekedar Informasi Untuk Sekarang Tema-labs Akan berhenti Update selama 1 bulan Di karenakan 
Komputer Mimin Masih Dalam Perbaikan Karna Biaya Yang Cukup Mahal jadi Proses Perbaikan Agak Lama
Jadi mimin tema-labs masih dalam pencarian BUDGET... 
Mohon Pengertianya jadi Bagi Yang ingin membuat laporan Feedback masalah Tema-labs Silahkan Kirim Via 
WA 082291462750 Spya saya Bisa rangkum dan catat , Kemajuan Tema-labs Bergantung Pada Komentar  Anda

