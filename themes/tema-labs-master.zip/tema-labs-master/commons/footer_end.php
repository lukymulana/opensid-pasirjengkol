<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
/**
 * footer_end.php
 *
 * Author: Labkoding.id tema-labs
 *
 * Silahkan Berdonasi Apabila
 * Berkemauan ,kami Membantu Opensid Dengan Segenap hati tanpa Bayaran
 * Apabila Agan Pengguna Tema Labs Sukarela Bedonasi  Silahkan langsung Saja Berdonasi
 *
 *
 */
?>
    </body>
</html>