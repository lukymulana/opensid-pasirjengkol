
<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
</main>
<?php $this->load->view("$folder_themes/includes/inc_footer.php"); ?>
</div>
