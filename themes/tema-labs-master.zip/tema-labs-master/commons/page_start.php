<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div id="page-container" class="main-content-boxed page-header-fixed side-trans-enabled page-header-inverse">  
    <?php $this->load->view("$folder_themes/includes/inc_header.php"); ?>
    <main id="main-container">
        <?php $this->load->view("$folder_themes/includes/inc_slider.php"); ?>