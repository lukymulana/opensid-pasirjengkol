<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div id="page-container" class="sidebar-inverse side-scroll page-header-fixed page-header-inverse main-content-boxed side-trans-enabled">
<?php $this->load->view("$folder_themes/includes/inc_header_mobile.php"); ?>   
<?php $this->load->view("$folder_themes/includes/inc_header.php"); ?>
<main id="main-container" style="min-height: 702px;">
<div class="content content-full">
