<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

 <?php $this->load->view("$folder_themes/mobile_widget/m_peta_lokasi_kantor.php"); ?>
 <?php $this->load->view("$folder_themes/mobile_widget/m_komentar.php"); ?>
 <?php $this->load->view("$folder_themes/mobile_widget/m_layanan_mandiri.php"); ?>
 <?php $this->load->view("$folder_themes/mobile_widget/m_statistik.php"); ?>
 <?php $this->load->view("$folder_themes/mobile_widget/m_aparatur.php"); ?>
 <?php $this->load->view("$folder_themes/mobile_widget/m_agenda.php"); ?>
 <?php $this->load->view("$folder_themes/mobile_widget/m_apbd.php"); ?>
 <?php $this->load->view("$folder_themes/mobile_widget/m_sosial_media.php"); ?>



